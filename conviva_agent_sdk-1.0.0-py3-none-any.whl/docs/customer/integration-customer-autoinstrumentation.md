### Conviva Agent SDK — Auto‑Instrumentation and Traces (Python)

This document complements the customer integration guide and explains what the SDK auto‑instruments after a minimal import and init, and what traces you should expect. The Python SDK wraps Traceloop (OpenLLMetry) instrumentations as a pinned dependency and exports via OTLP/HTTP to Conviva.

### What gets auto‑instrumented (Python)

Auto‑instrumentation is enabled by default. Without changing your code, the SDK observes calls across common AI SDKs, vector databases, and agent frameworks.

- LLM and Embeddings APIs (Python): OpenAI (incl. Agents), Anthropic, Cohere, Groq, Mistral AI, Google Generative AI, AWS Bedrock, Google Vertex AI, Ollama, Amazon SageMaker, Replicate, IBM watsonx
- Agent/Workflow Frameworks (Python): LangChain, LlamaIndex, Haystack, CrewAI, Transformers (selected pipelines)
- Vector and Document Stores (Python): Pinecone, Weaviate, Qdrant, ChromaDB, Milvus, LanceDB, Marqo
- Network/HTTP: outbound HTTP(S) calls made by the above SDKs (e.g., model API requests) are traced with timing and status metadata.

Notes
- Library coverage evolves over time; if your library is listed above, its core operations are traced out of the box.
- You do not need to add manual spans to benefit from auto‑instrumentation. You can add your own spans if you want additional app‑specific visibility.

### What traces are emitted

The SDK emits OpenTelemetry traces with AI‑aware attributes. Expect the following span types (names are illustrative):

- agent.graph.run (optional)
  - A high‑level span for a single agent request/run (when frameworks expose a run boundary), including overall latency and success/failure.
- agent.node (optional)
  - Per‑step spans for planning, retrieval, tool execution, etc., when the framework provides node hooks.
- llm.request / embedding.request
  - Emitted for model/embedding API calls. Attributes typically include provider, model name, latency, and token counts when available.
- vector.query / vector.upsert
  - Emitted for vector store operations with attributes like index/collection, top_k, filter flags, retrieved count, and latency.
- http.client
  - Underlying HTTP(S) calls with status code, target, and timings.

Content and privacy
- Traceloop can capture prompts/responses depending on library support. To disable content capture and send metadata-only spans, set:
  - `TRACELOOP_TRACE_CONTENT=false`
  - You can still add your own spans for additional context without payloads.

### Example: Python LangGraph agent

The example below shows a tiny LangGraph flow that calls an LLM. With the SDK initialized, LLM API calls and graph steps are captured automatically when supported libraries are used.

```python
import os
from conviva_agent_sdk import ConvivaAgentSDK

# Initialize once at process start
ConvivaAgentSDK.init(
    customer_key=os.environ.get("CONVIVA_CUSTOMER_KEY"),
    service_name="my-agent-service",
    service_version="1.0.0",
)

# --- Minimal LangGraph example ---
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from openai import OpenAI

class AgentState(TypedDict, total=False):
    user_input: str
    plan: str
    result: str

client = OpenAI()

def plan_node(state: AgentState) -> AgentState:
    prompt = f"Plan a short answer strategy for: {state['user_input']}"
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    plan_text = resp.choices[0].message.content
    return {**state, "plan": plan_text}

def execute_node(state: AgentState) -> AgentState:
    prompt = f"Using the plan: {state['plan']}\nAnswer the question: {state['user_input']}"
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    answer = resp.choices[0].message.content
    return {**state, "result": answer}

graph = StateGraph(AgentState)
graph.add_node("plan", plan_node)
graph.add_node("execute", execute_node)
graph.add_edge(START, "plan")
graph.add_edge("plan", "execute")
graph.add_edge("execute", END)
app = graph.compile()

out = app.invoke({"user_input": "Summarize the latest mission of Voyager 1."})
print(out.get("result"))

ConvivaAgentSDK.flush(5000)
ConvivaAgentSDK.shutdown(5000)
```

Resulting trace (conceptual)
```
agent.graph.run [my-agent-service]
  ├─ agent.node [plan]
  │   └─ llm.request [openai.chat.completions.create]
  └─ agent.node [execute]
      └─ llm.request [openai.chat.completions.create]
```

Each llm.request span typically includes attributes for provider (e.g., openai), model, latency, and—when available—input/output token counts. Vector store and tool execution steps would appear similarly when used in the flow.

### Need help?
If you use a library not listed above or want deeper spans for custom logic, you can still add manual OpenTelemetry spans alongside auto‑instrumentation. Contact your Conviva representative for guidance.


