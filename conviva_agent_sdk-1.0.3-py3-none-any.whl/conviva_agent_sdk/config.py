from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, List, Optional

from conviva_agent_sdk.logging_config import _sdk_logger as logger


@dataclass(frozen=True)
class ResolvedConfig:
    enabled: bool
    customer_key: Optional[str]
    service_name: str
    service_version: Optional[str]
    resource: Dict[str, str]
    headers: Dict[str, str]
    timeout_ms: int
    auto_include: List[str]
    auto_exclude: List[str]
    allow_test_endpoints: bool
    test_traces_endpoint_host: Optional[str]
    test_logs_endpoint_host: Optional[str]


RESERVED_HEADERS = {
    "host",
    "content-type",
    "content-encoding",
    "accept",
    "user-agent",
    "content-length",
    "authorization",
}


def _parse_csv_map(csv: Optional[str]) -> Dict[str, str]:
    logger.debug("Parsing CSV map from: %s", csv)
    result: Dict[str, str] = {}
    if not csv:
        logger.debug("No CSV string provided, returning empty dict")
        return result

    for raw in [s.strip() for s in csv.split(",") if s.strip()]:
        if "=" not in raw:
            logger.debug("Skipping malformed CSV entry (no '='): %s", raw)
            continue
        k, v = raw.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k:
            result[k] = v
            logger.debug("Added key-value pair: %s=%s", k, v)
        else:
            logger.debug("Skipping entry with empty key: %s", raw)

    logger.debug("Parsed CSV map result: %s", result)
    return result


def _parse_csv_list(csv: Optional[str]) -> List[str]:
    logger.debug("Parsing CSV list from: %s", csv)
    if not csv:
        logger.debug("No CSV string provided, returning empty list")
        return []

    result = [s.strip() for s in csv.split(",") if s.strip()]
    logger.debug("Parsed CSV list result: %s", result)
    return result


def sanitize_headers(
    user: Optional[Dict[str, str]], required: Dict[str, str]
) -> Dict[str, str]:
    logger.debug("Sanitizing headers - user: %s, required: %s", user, required)
    headers: Dict[str, str] = dict(required)

    if user:
        for k, v in user.items():
            if k.lower() in RESERVED_HEADERS:
                logger.debug("Skipping reserved header: %s", k)
                continue
            headers[k] = v
            logger.debug("Added user header: %s=%s", k, v)

    logger.debug("Final sanitized headers: %s", headers)
    return headers


def resolve_config(
    *,
    customer_key: Optional[str] = None,
    service_name: Optional[str] = None,
    service_version: Optional[str] = None,
    resource: Optional[Dict[str, str]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout_ms: Optional[int] = None,
    auto_include: Optional[List[str]] = None,
    auto_exclude: Optional[List[str]] = None,
    enabled: Optional[bool] = None,
) -> ResolvedConfig:
    logger.info(
        "Resolving configuration with parameters: customer_key=%s, service_name=%s, service_version=%s, enabled=%s",
        customer_key,
        service_name,
        service_version,
        enabled,
    )

    # Check if SDK is disabled via environment
    disabled_env = os.getenv("CONVIVA_SDK_DISABLED")
    enabled_val = enabled if isinstance(enabled, bool) else not (disabled_env == "true")
    logger.debug(
        "SDK enabled status: %s (env: %s, param: %s)",
        enabled_val,
        disabled_env,
        enabled,
    )

    # Resolve customer key
    customer_key_val = customer_key or os.getenv("CONVIVA_CUSTOMER_KEY")
    logger.debug(
        "Customer key resolved: %s (param: %s, env: %s)",
        customer_key_val,
        customer_key,
        os.getenv("CONVIVA_CUSTOMER_KEY"),
    )

    # Resolve service name
    service_name_val = (
        service_name
        or os.getenv("CONVIVA_SERVICE_NAME")
        or os.getenv("OTEL_SERVICE_NAME")
        or "unknown_service:python"
    )
    logger.debug(
        "Service name resolved: %s (param: %s, env CONVIVA: %s, env OTEL: %s)",
        service_name_val,
        service_name,
        os.getenv("CONVIVA_SERVICE_NAME"),
        os.getenv("OTEL_SERVICE_NAME"),
    )

    # Resolve service version
    service_version_val = service_version or os.getenv("CONVIVA_SERVICE_VERSION")
    logger.debug(
        "Service version resolved: %s (param: %s, env: %s)",
        service_version_val,
        service_version,
        os.getenv("CONVIVA_SERVICE_VERSION"),
    )

    # Resolve resource attributes
    resource_env = _parse_csv_map(
        os.getenv("CONVIVA_RESOURCE_ATTRIBUTES")
        or os.getenv("OTEL_RESOURCE_ATTRIBUTES")
    )
    resource_val = {**resource_env, **(resource or {})}
    logger.debug(
        "Resource attributes resolved: %s (env: %s, param: %s)",
        resource_val,
        resource_env,
        resource,
    )

    # Resolve auto-include/exclude lists
    auto_include_val = auto_include or _parse_csv_list(
        os.getenv("CONVIVA_AUTO_INCLUDE")
    )
    auto_exclude_val = auto_exclude or _parse_csv_list(
        os.getenv("CONVIVA_AUTO_EXCLUDE")
    )
    logger.debug(
        "Auto-include resolved: %s (param: %s, env: %s)",
        auto_include_val,
        auto_include,
        os.getenv("CONVIVA_AUTO_INCLUDE"),
    )
    logger.debug(
        "Auto-exclude resolved: %s (param: %s, env: %s)",
        auto_exclude_val,
        auto_exclude,
        os.getenv("CONVIVA_AUTO_EXCLUDE"),
    )

    # Resolve timeout
    timeout_val = timeout_ms if isinstance(timeout_ms, int) else 10_000
    logger.debug("Timeout resolved: %s ms (param: %s)", timeout_val, timeout_ms)

    # Resolve test endpoint settings
    allow_test = os.getenv("CONVIVA_ALLOW_TEST_ENDPOINTS") == "true"
    test_traces = os.getenv("CONVIVA_TRACES_ENDPOINT")
    test_logs = os.getenv("CONVIVA_LOGS_ENDPOINT")
    logger.debug(
        "Test endpoints - allowed: %s, traces: %s, logs: %s",
        allow_test,
        test_traces,
        test_logs,
    )

    config = ResolvedConfig(
        enabled=enabled_val,
        customer_key=customer_key_val,
        service_name=service_name_val,
        service_version=service_version_val,
        resource=resource_val,
        headers=headers or {},
        timeout_ms=timeout_val,
        auto_include=auto_include_val,
        auto_exclude=auto_exclude_val,
        allow_test_endpoints=allow_test,
        test_traces_endpoint_host=test_traces,
        test_logs_endpoint_host=test_logs,
    )

    logger.info("Configuration resolved successfully: %s", config)
    return config


def compute_prod_endpoints(customer_key: str) -> Dict[str, str]:
    logger.info("Computing production endpoints for customer key: %s", customer_key)

    # Allow overriding the AGW domain via env; default to agw.conviva.com
    raw_domain = os.getenv("CONVIVA_AGW_DOMAIN") or "agw.conviva.com"
    domain = raw_domain.strip()
    logger.debug("Raw domain from env: %s", raw_domain)

    try:
        from urllib.parse import urlparse

        parsed = urlparse(domain if domain.startswith("http") else f"https://{domain}")
        logger.debug("Parsed domain URL: %s", parsed)

        # Use host (hostname[:port]) and discard any path/query
        host = parsed.netloc or parsed.path
        domain = host.strip("/") or "agw.conviva.com"
        logger.debug("Extracted host from parsed URL: %s", host)
        logger.debug("Final domain: %s", domain)

    except Exception as e:
        logger.warning("Failed to parse domain '%s', using fallback: %s", domain, e)
        domain = (domain or "agw.conviva.com").strip("/")

    if customer_key:
        base = f"https://{customer_key}.{domain}"
    else:
        base = f"https://{domain}"
    traces_url = f"{base}/v1/traces"
    logs_url = f"{base}/v1/logs"

    endpoints = {"traces_url": traces_url, "logs_url": logs_url}
    logger.info("Production endpoints computed: %s", endpoints)
    return endpoints


def is_localhost_host(hostname: str) -> bool:
    is_local = hostname in {"localhost", "127.0.0.1"}
    logger.debug("Hostname '%s' is localhost: %s", hostname, is_local)
    return is_local


def build_test_endpoints(
    traces_host: Optional[str], logs_host: Optional[str]
) -> Optional[Dict[str, str]]:
    logger.info(
        "Building test endpoints - traces_host: %s, logs_host: %s",
        traces_host,
        logs_host,
    )

    if not traces_host or not logs_host:
        logger.warning(
            "Missing test endpoint hosts - traces: %s, logs: %s", traces_host, logs_host
        )
        return None

    try:
        from urllib.parse import urlparse

        def norm(h: str) -> str:
            normalized = h if h.startswith("http") else f"http://{h}"
            logger.debug("Normalized host '%s' to '%s'", h, normalized)
            return normalized

        trace_url = urlparse(norm(traces_host))
        logs_url = urlparse(norm(logs_host))
        logger.debug("Parsed traces URL: %s", trace_url)
        logger.debug("Parsed logs URL: %s", logs_url)

        if not is_localhost_host(trace_url.hostname or "") or not is_localhost_host(
            logs_url.hostname or ""
        ):
            logger.warning(
                "Test endpoints must be localhost - traces hostname: %s, logs hostname: %s",
                trace_url.hostname,
                logs_url.hostname,
            )
            return None

        # Default OTLP/HTTP port to 4318 for HTTP when port is not provided
        trace_port = trace_url.port or (
            4318 if (trace_url.scheme or "").lower() == "http" else None
        )
        logs_port = logs_url.port or (
            4318 if (logs_url.scheme or "").lower() == "http" else None
        )
        logger.debug("Ports resolved - traces: %s, logs: %s", trace_port, logs_port)

        traces_url = (
            f"{trace_url.scheme}://{trace_url.hostname}:{trace_port}"
            if trace_port
            else f"{trace_url.scheme}://{trace_url.hostname}"
        )
        logs_url = (
            f"{logs_url.scheme}://{logs_url.hostname}:{logs_port}"
            if logs_port
            else f"{logs_url.scheme}://{logs_url.hostname}"
        )

        endpoints = {
            "traces_url": f"{traces_url}/v1/traces",
            "logs_url": f"{logs_url}/v1/logs",
        }
        logger.info("Test endpoints built successfully: %s", endpoints)
        return endpoints

    except Exception as e:
        logger.error("Failed to build test endpoints: %s", e)
        return None
