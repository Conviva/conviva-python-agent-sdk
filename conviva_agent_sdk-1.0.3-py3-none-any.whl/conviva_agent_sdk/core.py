from __future__ import annotations
import threading
from typing import Dict, List, Optional, Set

import os
from opentelemetry import baggage, context
from opentelemetry.sdk.trace import SpanProcessor
from contextlib import contextmanager

from .config import (
    ResolvedConfig,
    resolve_config,
    compute_prod_endpoints,
    build_test_endpoints,
    sanitize_headers,
)

from conviva_agent_sdk.logging_config import _sdk_logger as logger


class BaggageToAttributesSpanProcessor(SpanProcessor):
    def __init__(self):
        allowed = os.getenv("CONVIVA_TRACING_CONTEXT_KEYS", "convID,client_id")
        # normalize to lowercase
        self.allowed_keys = {k.strip().lower() for k in allowed.split(",") if k.strip()}
        self.max_value_len = int(
            os.getenv("CONVIVA_TRACING_CONTEXT_MAX_VALUE_LEN", "256")
        )
        self.namespace = os.getenv("CONVIVA_TRACING_CONTEXT_NAMESPACE", "c3.")

    def on_start(self, span, parent_context):
        logger.debug(">>> on_start called")
        logger.debug(">>> baggage keys: %s", baggage.get_all(parent_context))

        if not span.is_recording():
            logger.debug("Span is not recording")
            return

        # Prefer parent_context, fallback to current
        ctx = parent_context or context.get_current()
        items = baggage.get_all(ctx) or {}
        logger.debug("Baggage items: %s", items)

        for k, v in items.items():
            norm_key = k.lower()
            logger.debug(
                "Processing baggage item: %s = %s in ALLOWED: %s",
                k,
                v,
                self.allowed_keys,
            )
            if norm_key not in self.allowed_keys:
                continue
            sval = str(v)
            if len(sval) > self.max_value_len:
                sval = sval[: self.max_value_len] + "…"
            logger.info("Setting attribute: %s%s = %s", self.namespace, k, sval)
            span.set_attribute(f"{self.namespace}{k}", sval)

    def on_end(self, span):
        pass

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


class ConvivaAgentSDK:
    _instance = None
    _lock = threading.Lock()
    _initialized = False
    _tp: object | None = None

    @classmethod
    def get_instance(cls):
        logger.debug("Getting SDK instance (current: %s)", cls._instance)
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    logger.debug("Creating new SDK instance")
                    cls._instance = cls()
                else:
                    logger.debug("Instance already created by another thread")
        else:
            logger.debug("Returning existing SDK instance")
        return cls._instance

    @staticmethod
    def _compute_endpoints(cfg: ResolvedConfig) -> Optional[Dict[str, str]]:
        logger.info("Computing endpoints for configuration: %s", cfg)

        if not cfg.enabled:
            logger.info("SDK is disabled, skipping endpoint computation")
            return None

        if cfg.allow_test_endpoints:
            logger.info(
                "Allowing test endpoints - traces: %s, logs: %s",
                cfg.test_traces_endpoint_host,
                cfg.test_logs_endpoint_host,
            )
            endpoints = build_test_endpoints(
                cfg.test_traces_endpoint_host, cfg.test_logs_endpoint_host
            )
            if endpoints:
                logger.info("Using test endpoints: %s", endpoints)
                return endpoints
            else:
                logger.warning("Test endpoints requested but could not be built")

        if cfg.customer_key:
            logger.info(
                "Computing production endpoints for customer key: %s", cfg.customer_key
            )
            prod_endpoints = compute_prod_endpoints(cfg.customer_key)
            logger.info("Using production endpoints: %s", prod_endpoints)
            return prod_endpoints

        # this is to handle case where we want to set end point without customer key prefix logic
        if not cfg.customer_key:
            prod_endpoints = compute_prod_endpoints(cfg.customer_key)
            logger.info("Using production endpoints: %s", prod_endpoints)
            return prod_endpoints

        logger.warning(
            "No endpoints could be computed - no customer key and test endpoints not available"
        )
        return None

    @staticmethod
    def _build_otlp_span_exporter(cfg: ResolvedConfig, *, traces_url: str):
        logger.debug("Building OTLP span exporter for URL: %s", traces_url)
        logger.debug(
            "Exporter configuration - headers: %s, timeout: %d ms",
            cfg.headers,
            cfg.timeout_ms,
        )

        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter,
                Compression,
            )  # type: ignore

            logger.debug("Successfully imported OTLP exporter")
        except Exception as e:
            logger.error("Failed to import OTLP exporter: %s", e)
            return None

        headers = sanitize_headers(cfg.headers, {})
        timeout_s = max(1, int(round(cfg.timeout_ms / 1000)))
        logger.debug("Sanitized headers: %s, timeout: %d seconds", headers, timeout_s)

        try:
            exporter = OTLPSpanExporter(
                endpoint=traces_url,
                headers=headers,
                timeout=timeout_s,
                compression=Compression.Gzip,
            )  # type: ignore
            logger.info("OTLP exporter created successfully with gzip compression")
        except TypeError as e:
            logger.warning(
                "OTLP exporter created without compression due to TypeError: %s", e
            )
            exporter = OTLPSpanExporter(endpoint=traces_url, headers=headers)  # type: ignore
            logger.info("OTLP exporter created without compression")

        return exporter

    @staticmethod
    def _to_instruments(names: List[str]):
        logger.debug("Converting instrument names to Instruments: %s", names)
        from traceloop.sdk.instruments import Instruments  # type: ignore

        result: Set[Instruments] = set()

        for n in names or []:
            key = (n or "").strip()
            if not key:
                logger.debug("Skipping empty instrument name")
                continue

            try:
                instrument = Instruments[key.upper()]
                result.add(instrument)
                logger.debug("Added instrument by key: %s -> %s", key, instrument)
                continue
            except Exception as e:
                logger.debug("Failed to add instrument by key '%s': %s", key, e)

            try:
                for item in Instruments:
                    if item.value == key.lower():
                        result.add(item)
                        logger.debug("Added instrument by value: %s -> %s", key, item)
                        break
            except Exception as e:
                logger.debug("Failed to add instrument by value '%s': %s", key, e)
                continue

        logger.debug("Final instrument set: %s", result)
        return result

    @classmethod
    def init(
        cls,
        *,
        customer_key: Optional[str] = None,
        service_name: Optional[str] = None,
        service_version: Optional[str] = None,
        resource: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout_ms: int = 10_000,
        auto_include: Optional[List[str]] = None,
        auto_exclude: Optional[List[str]] = None,
        auto_instrumentation: bool = True,
        enabled: bool = True,
    ) -> None:
        logger.info(
            "Initializing SDK with parameters: customer_key=%s, service_name=%s, service_version=%s, "
            "timeout_ms=%d, auto_instrumentation=%s, enabled=%s",
            customer_key,
            service_name,
            service_version,
            timeout_ms,
            auto_instrumentation,
            enabled,
        )
        logger.debug(
            "Additional parameters - resource: %s, headers: %s, auto_include: %s, auto_exclude: %s",
            resource,
            headers,
            auto_include,
            auto_exclude,
        )

        with cls._lock:
            if cls._initialized:
                logger.info("SDK is already initialized, skipping init")
                return

            logger.info("SDK initialization starting")
            cls._initialized = True

            # Resolve configuration
            logger.debug("Resolving configuration...")
            cfg: ResolvedConfig = resolve_config(
                customer_key=customer_key,
                service_name=service_name,
                service_version=service_version,
                resource=resource,
                headers=headers,
                timeout_ms=timeout_ms,
                auto_include=auto_include,
                auto_exclude=auto_exclude,
                enabled=enabled,
            )
            logger.debug("Configuration resolved: %s", cfg)

            # Compute endpoints
            logger.debug("Computing endpoints...")
            endpoints = cls._compute_endpoints(cfg)
            if not endpoints:
                logger.warning("No endpoints available, skipping tracer setup")
                return

            traces_url = endpoints.get("traces_url")
            if not traces_url:
                logger.warning("Traces URL not found in endpoints: %s", endpoints)
                return

            logger.info("Using traces URL: %s", traces_url)

            # Prepare exporter
            logger.debug("Building OTLP exporter...")
            exporter = cls._build_otlp_span_exporter(cfg, traces_url=traces_url)
            if exporter is None:
                logger.warning("Failed creating OTLP exporter")
                return

            # Set environment variables
            logger.debug(
                "Setting environment variables for Traceloop and OpenTelemetry"
            )
            os.environ.setdefault("TRACELOOP_TELEMETRY", "false")
            os.environ.setdefault("TRACELOOP_SUPPRESS_WARNINGS", "true")
            os.environ.setdefault("OTEL_PROPAGATORS", "tracecontext,baggage")

            # Exclude Conviva tracking endpoints to prevent feedback loops
            conviva_exclude_list = [
                "conviva.com/v1/traces",
                "conviva.com/v1/logs",
                "localhost",
            ]
            existing = os.environ.get("OTEL_PYTHON_REQUESTS_EXCLUDED_URLS", "")
            if existing:
                combined = ",".join([existing] + conviva_exclude_list)
            else:
                combined = ",".join(conviva_exclude_list)

            logger.debug("Combined exclude list: %s", combined)
            os.environ["OTEL_PYTHON_REQUESTS_EXCLUDED_URLS"] = combined
            if not auto_instrumentation:
                os.environ["TRACELOOP_TRACING_ENABLED"] = "false"
                logger.debug("Auto-instrumentation disabled via environment")

            # Import required modules
            try:
                from traceloop.sdk import Traceloop  # type: ignore
                from opentelemetry import trace as _otel_trace  # type: ignore

                logger.debug(
                    "Successfully imported Traceloop and OpenTelemetry modules"
                )
            except Exception as e:
                logger.error("Traceloop SDK import failed: %s", e)
                return

            # Prepare resource attributes
            resource_attrs: Dict[str, str] = {"service.name": cfg.service_name}
            if cfg.service_version:
                resource_attrs["service.version"] = cfg.service_version
            for k, v in (cfg.resource or {}).items():
                resource_attrs[k] = v
            logger.debug("Resource attributes prepared: %s", resource_attrs)

            # Convert instrument lists
            include_set = cls._to_instruments(cfg.auto_include)
            exclude_set = cls._to_instruments(cfg.auto_exclude)
            logger.debug(
                "Instrument sets - include: %s, exclude: %s", include_set, exclude_set
            )

            # Initialize Traceloop
            try:
                logger.info(
                    "Initializing Traceloop SDK with service name: %s", cfg.service_name
                )
                Traceloop.init(
                    app_name=cfg.service_name,
                    exporter=exporter,
                    disable_batch=False,
                    telemetry_enabled=False,
                    enabled=auto_instrumentation,
                    resource_attributes=resource_attrs,
                    instruments=(include_set if include_set else None),
                    block_instruments=(exclude_set if exclude_set else None),
                    traceloop_sync_enabled=False,
                )
                logger.info("Traceloop SDK initialized successfully")

                # Get tracer provider
                provider = _otel_trace.get_tracer_provider()  # type: ignore
                if provider is None:
                    logger.warning("Traceloop initialized but no tracer provider found")
                    return

                cls._tp = provider
                logger.info("Tracer provider adding span processor")
                provider.add_span_processor(BaggageToAttributesSpanProcessor())
                logger.info("Tracer provider successfully set up (traceloop path)")

            except Exception as e:
                logger.error("Failed to initialize Traceloop SDK: %s", e)
                return

            logger.info("SDK initialization completed successfully")

    @classmethod
    def flush(cls, timeout_ms: Optional[int] = None) -> None:
        logger.info("Flushing spans with timeout: %s ms", timeout_ms)

        try:
            if cls._tp is None:
                logger.warning("No tracer provider available for flush")
                return

            timeout_val = int(timeout_ms) if isinstance(timeout_ms, int) else 10_000
            logger.debug("Using timeout value: %d ms", timeout_val)

            if hasattr(cls._tp, "force_flush"):
                logger.info("Flushing spans with timeout %d ms...", timeout_val)
                cls._tp.force_flush(timeout_val)  # type: ignore[attr-defined]
                logger.info("Flush completed successfully")
            else:
                logger.warning("Tracer provider does not have force_flush method")

        except Exception as e:
            logger.error("Exception during flush: %s", e)

    @classmethod
    def shutdown(cls, timeout_ms: Optional[int] = None) -> None:
        logger.info("Shutting down SDK with timeout: %s ms", timeout_ms)
        _ = timeout_ms

        try:
            if cls._tp is not None and hasattr(cls._tp, "shutdown"):
                logger.info("Shutting down tracer provider...")
                cls._tp.shutdown()  # type: ignore[attr-defined]
                logger.info("Tracer provider shutdown completed")
            else:
                logger.debug(
                    "No tracer provider to shutdown or missing shutdown method"
                )

        except Exception as e:
            logger.error("Exception during tracer shutdown: %s", e)

        # Reset state
        cls._initialized = False
        cls._tp = None
        logger.info("SDK shutdown completed, state cleared")

    @staticmethod
    def _attach_tracing_context(tracing_dict: dict[str, str]) -> object:
        """
        Attach baggage for current request.
        Returns a token that must be passed to detach_baggage().
        """
        ctx = context.get_current()
        for k, v in (tracing_dict or {}).items():
            if v:
                logger.debug("Attaching tracing %s=%s", k, v)
                ctx = baggage.set_baggage(k, v, context=ctx)
        token = context.attach(ctx)
        return token

    @staticmethod
    def _detach_tracing_context(token: object) -> None:
        """
        Detach tracing using the token returned by attach_tracing_context().
        """
        try:
            context.detach(token)
            logger.debug("Detached tracing context")
        except Exception as e:
            logger.warning("Failed to detach tracing context: %s", e)

    @staticmethod
    @contextmanager
    def tracing_context(tracing_dict: dict[str, str]):
        """
        Context manager form: auto attach/detach baggage.
        Usage:
            with ConvivaAgentSDK.tracing_context({"convID": "abc"}):
                ...
        """
        token = ConvivaAgentSDK._attach_tracing_context(tracing_dict)
        try:
            yield
        finally:
            ConvivaAgentSDK._detach_tracing_context(token)

    @staticmethod
    def set_tracing_context(tracing_dict: dict[str, str]) -> object:
        """
        Set tracing for current request.
        """
        token = ConvivaAgentSDK._attach_tracing_context(tracing_dict)
        return token

    @staticmethod
    def detach_tracing_context(token: object) -> None:
        """
        Detach tracing using the token returned by attach_tracing_context().
        """
        ConvivaAgentSDK._detach_tracing_context(token)
