import logging
import os

# Root logger for the SDK (all submodules inherit from this)
_sdk_logger = logging.getLogger("conviva_agent_sdk")
_sdk_logger.addHandler(logging.NullHandler())

# Special "OFF" level
OFF = logging.CRITICAL + 1


def set_log_level(level: str | int) -> None:
    """
    Set ConvivaAgentSDK log level.

    Accepts: "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL", "OFF" or int.
    """
    if isinstance(level, str):
        level = level.strip().upper()
        if level == "OFF":
            _sdk_logger.setLevel(OFF)
            return
        level = getattr(logging, level, logging.INFO)
    _sdk_logger.setLevel(level)


def suppress_logs() -> None:
    """Completely suppress ConvivaAgentSDK logs."""
    _sdk_logger.setLevel(OFF)


def enable_logs(level: str | int = "INFO") -> None:
    """Enable ConvivaAgentSDK logs at the given level."""
    set_log_level(level)


def apply_env_level() -> None:
    """Apply CONVIVA_LOG_LEVEL from environment, if present."""
    level = os.getenv("CONVIVA_LOG_LEVEL")
    if level:
        set_log_level(level)
    else:
        set_log_level("INFO")


# Auto-apply at import time
apply_env_level()
