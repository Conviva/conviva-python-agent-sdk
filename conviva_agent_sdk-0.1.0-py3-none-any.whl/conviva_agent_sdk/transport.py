from __future__ import annotations

import json
import sys
import urllib.request
from dataclasses import dataclass
from typing import Dict, Optional

from .config import sanitize_headers


@dataclass
class SendResult:
    ok: bool
    status: Optional[int] = None


def send_otlp_http(*, url: str, body: bytes, user_headers: Optional[Dict[str, str]], timeout_ms: int) -> SendResult:
    required = {
        "Content-Type": "application/x-protobuf",
        "Content-Encoding": "gzip",
        "Accept": "application/x-protobuf",
    }
    headers = sanitize_headers(user_headers, required)
    req = urllib.request.Request(url=url, data=body, headers=headers, method="POST")
    timeout_s = max(0.001, timeout_ms / 1000)
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:  # nosec B310
            status = getattr(resp, "status", 200)
            ok = 200 <= status < 300
            return SendResult(ok=ok, status=status)
    except urllib.error.HTTPError as e:  # type: ignore[attr-defined]
        return SendResult(ok=False, status=getattr(e, "code", None))
    except Exception:
        return SendResult(ok=False, status=None)



