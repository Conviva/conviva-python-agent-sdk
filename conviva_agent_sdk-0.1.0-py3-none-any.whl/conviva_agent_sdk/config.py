from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ResolvedConfig:
    enabled: bool
    customer_key: Optional[str]
    service_name: str
    service_version: Optional[str]
    resource: Dict[str, str]
    headers: Dict[str, str]
    timeout_ms: int
    auto_include: List[str]
    auto_exclude: List[str]
    allow_test_endpoints: bool
    test_traces_endpoint_host: Optional[str]
    test_logs_endpoint_host: Optional[str]


RESERVED_HEADERS = {
    "host",
    "content-type",
    "content-encoding",
    "accept",
    "user-agent",
    "content-length",
    "authorization",
}


def _parse_csv_map(csv: Optional[str]) -> Dict[str, str]:
    result: Dict[str, str] = {}
    if not csv:
        return result
    for raw in [s.strip() for s in csv.split(",") if s.strip()]:
        if "=" not in raw:
            continue
        k, v = raw.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k:
            result[k] = v
    return result


def _parse_csv_list(csv: Optional[str]) -> List[str]:
    if not csv:
        return []
    return [s.strip() for s in csv.split(",") if s.strip()]


def sanitize_headers(user: Optional[Dict[str, str]], required: Dict[str, str]) -> Dict[str, str]:
    headers: Dict[str, str] = dict(required)
    if user:
        for k, v in user.items():
            if k.lower() in RESERVED_HEADERS:
                continue
            headers[k] = v
    return headers


def resolve_config(
    *,
    customer_key: Optional[str] = None,
    service_name: Optional[str] = None,
    service_version: Optional[str] = None,
    resource: Optional[Dict[str, str]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout_ms: Optional[int] = None,
    auto_include: Optional[List[str]] = None,
    auto_exclude: Optional[List[str]] = None,
    enabled: Optional[bool] = None,
) -> ResolvedConfig:
    disabled_env = os.getenv("CONVIVA_SDK_DISABLED")
    enabled_val = enabled if isinstance(enabled, bool) else not (disabled_env == "true")

    customer_key_val = customer_key or os.getenv("CONVIVA_CUSTOMER_KEY")
    service_name_val = (
        service_name
        or os.getenv("CONVIVA_SERVICE_NAME")
        or os.getenv("OTEL_SERVICE_NAME")
        or "unknown_service:python"
    )
    service_version_val = service_version or os.getenv("CONVIVA_SERVICE_VERSION")

    resource_env = _parse_csv_map(
        os.getenv("CONVIVA_RESOURCE_ATTRIBUTES") or os.getenv("OTEL_RESOURCE_ATTRIBUTES")
    )
    resource_val = {**resource_env, **(resource or {})}

    auto_include_val = auto_include or _parse_csv_list(os.getenv("CONVIVA_AUTO_INCLUDE"))
    auto_exclude_val = auto_exclude or _parse_csv_list(os.getenv("CONVIVA_AUTO_EXCLUDE"))

    timeout_val = timeout_ms if isinstance(timeout_ms, int) else 10_000

    allow_test = os.getenv("CONVIVA_ALLOW_TEST_ENDPOINTS") == "true"
    test_traces = os.getenv("CONVIVA_TRACES_ENDPOINT")
    test_logs = os.getenv("CONVIVA_LOGS_ENDPOINT")

    return ResolvedConfig(
        enabled=enabled_val,
        customer_key=customer_key_val,
        service_name=service_name_val,
        service_version=service_version_val,
        resource=resource_val,
        headers=headers or {},
        timeout_ms=timeout_val,
        auto_include=auto_include_val,
        auto_exclude=auto_exclude_val,
        allow_test_endpoints=allow_test,
        test_traces_endpoint_host=test_traces,
        test_logs_endpoint_host=test_logs,
    )


def compute_prod_endpoints(customer_key: str) -> Dict[str, str]:
    # Allow overriding the AGW domain via env; default to agw.conviva.com
    raw_domain = os.getenv("CONVIVA_AGW_DOMAIN") or "agw.conviva.com"
    domain = raw_domain.strip()
    try:
        from urllib.parse import urlparse

        parsed = urlparse(domain if domain.startswith("http") else f"https://{domain}")
        # Use host (hostname[:port]) and discard any path/query
        host = parsed.netloc or parsed.path
        domain = host.strip("/") or "agw.conviva.com"
    except Exception:
        domain = (domain or "agw.conviva.com").strip("/")
    base = f"https://{customer_key}.{domain}"
    return {"traces_url": f"{base}/v1/traces", "logs_url": f"{base}/v1/logs"}


def is_localhost_host(hostname: str) -> bool:
    return hostname in {"localhost", "127.0.0.1"}


def build_test_endpoints(traces_host: Optional[str], logs_host: Optional[str]) -> Optional[Dict[str, str]]:
    if not traces_host or not logs_host:
        return None
    try:
        from urllib.parse import urlparse

        def norm(h: str) -> str:
            return h if h.startswith("http") else f"http://{h}"

        t = urlparse(norm(traces_host))
        l = urlparse(norm(logs_host))
        if not is_localhost_host(t.hostname or "") or not is_localhost_host(l.hostname or ""):
            return None
        # Default OTLP/HTTP port to 4318 for HTTP when port is not provided
        t_port = t.port or (4318 if (t.scheme or "").lower() == "http" else None)
        l_port = l.port or (4318 if (l.scheme or "").lower() == "http" else None)
        traces_url = f"{t.scheme}://{t.hostname}:{t_port}" if t_port else f"{t.scheme}://{t.hostname}"
        logs_url = f"{l.scheme}://{l.hostname}:{l_port}" if l_port else f"{l.scheme}://{l.hostname}"
        return {"traces_url": f"{traces_url}/v1/traces", "logs_url": f"{logs_url}/v1/logs"}
    except Exception:
        return None



