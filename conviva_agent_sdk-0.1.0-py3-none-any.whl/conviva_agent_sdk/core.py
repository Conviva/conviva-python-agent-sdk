from __future__ import annotations

import logging
import threading
from typing import Dict, List, Optional, Set

from .config import (
    ResolvedConfig,
    resolve_config,
    compute_prod_endpoints,
    build_test_endpoints,
    sanitize_headers,
)
from .health import HealthManager
import os

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

logging.basicConfig(level=logging.INFO)
logging.getLogger("opentelemetry").setLevel(logging.DEBUG)

class ConvivaAgentSDK:
    _instance = None
    _lock = threading.Lock()
    _initialized = False
    _health: HealthManager | None = None
    _tp: object | None = None
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance


    @staticmethod
    def _compute_endpoints(cfg: ResolvedConfig) -> Optional[Dict[str, str]]:
        logger.info("Computing endpoints...")
        if not cfg.enabled:
            logger.info("SDK is disabled, skipping endpoint computation.")
            return None

        if cfg.allow_test_endpoints:
            logger.info("Allowing test endpoints.")
            endpoints = build_test_endpoints(cfg.test_traces_endpoint_host, cfg.test_logs_endpoint_host)
            if endpoints:
                logger.info("Using test endpoints: %s", endpoints)
                return endpoints

        if cfg.customer_key:
            prod_endpoints = compute_prod_endpoints(cfg.customer_key)
            logger.info("Using production endpoints: %s", prod_endpoints)
            return prod_endpoints

        logger.warning("No endpoints could be computed.")
        return None


    @staticmethod
    def _build_otlp_span_exporter(cfg: ResolvedConfig, *, traces_url: str):
        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter, Compression  # type: ignore
        except Exception as e:
            logger.error("Failed to import OTLP exporter: %s", e)
            return None

        headers = sanitize_headers(cfg.headers, {})
        timeout_s = max(1, int(round(cfg.timeout_ms / 1000)))
        try:
            exporter = OTLPSpanExporter(endpoint=traces_url, headers=headers, timeout=timeout_s, compression=Compression.Gzip)  # type: ignore
            logger.info("OTLP exporter created with gzip compression.")
        except TypeError:
            exporter = OTLPSpanExporter(endpoint=traces_url, headers=headers)  # type: ignore
            logger.warning("OTLP exporter created without compression due to TypeError.")
        return exporter


    @staticmethod
    def _to_instruments(names: List[str]):
        from traceloop.sdk.instruments import Instruments  # type: ignore
        result: Set[Instruments] = set()
        for n in names or []:
            key = (n or "").strip()
            if not key:
                continue
            try:
                result.add(Instruments[key.upper()])
                continue
            except Exception:
                pass
            try:
                for item in Instruments:
                    if item.value == key.lower():
                        result.add(item)
                        break
            except Exception:
                continue
        return result


    @classmethod
    def init(
        cls,
        *,
        customer_key: Optional[str] = None,
        service_name: Optional[str] = None,
        service_version: Optional[str] = None,
        resource: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout_ms: int = 10_000,
        auto_include: Optional[List[str]] = None,
        auto_exclude: Optional[List[str]] = None,
        auto_instrumentation: bool = True,
        enabled: bool = True,
    ) -> None:
        with cls._lock:
            if cls._initialized:
                logger.info("SDK is already initialized, skipping init.")
                return

        logger.info("Initializing SDK with service_name=%s, customer_key=%s", service_name, customer_key)
        cls._initialized = True
        cfg: ResolvedConfig = resolve_config(
            customer_key=customer_key,
            service_name=service_name,
            service_version=service_version,
            resource=resource,
            headers=headers,
            timeout_ms=timeout_ms,
            auto_include=auto_include,
            auto_exclude=auto_exclude,
            enabled=enabled,
        )
        cls._health = HealthManager(5)
        logger.info("Health manager initialized.")

        endpoints = cls._compute_endpoints(cfg)
        if not endpoints:
            logger.warning("No endpoints available, skipping tracer setup.")
            return

        traces_url = endpoints.get("traces_url")
        if not traces_url:
            logger.warning("Traces URL not found in endpoints, skipping tracer setup.")
            return

        # Prepare exporter once
        exporter = cls._build_otlp_span_exporter(cfg, traces_url=traces_url)
        if exporter is None:
            logger.warning("Failed creating OTLP exporter.")
            return

        # Suppress any SDK telemetry and warnings from Traceloop
        os.environ.setdefault("TRACELOOP_TELEMETRY", "false")
        os.environ.setdefault("TRACELOOP_SUPPRESS_WARNINGS", "true")
        # Ensure default OpenTelemetry propagators if not provided by user
        os.environ.setdefault("OTEL_PROPAGATORS", "tracecontext,baggage")
        if not auto_instrumentation:
            os.environ["TRACELOOP_TRACING_ENABLED"] = "false"

        try:
            from traceloop.sdk import Traceloop  # type: ignore
            from opentelemetry import trace as _otel_trace  # type: ignore
        except Exception as e:
            logger.error("Traceloop SDK import failed: %s", e)
            return

        resource_attrs: Dict[str, str] = {"service.name": cfg.service_name}
        if cfg.service_version:
            resource_attrs["service.version"] = cfg.service_version
        for k, v in (cfg.resource or {}).items():
            resource_attrs[k] = v

        include_set = cls._to_instruments(cfg.auto_include)
        exclude_set = cls._to_instruments(cfg.auto_exclude)

        try:
            Traceloop.init(
                app_name=cfg.service_name,
                exporter=exporter,
                disable_batch=False,
                telemetry_enabled=False,
                enabled=auto_instrumentation,
                resource_attributes=resource_attrs,
                instruments=(include_set if include_set else None),
                block_instruments=(exclude_set if exclude_set else None),
                traceloop_sync_enabled=False,
            )
            provider = _otel_trace.get_tracer_provider()  # type: ignore
            if provider is None:
                logger.warning("Traceloop initialized but no tracer provider found.")
                return
            cls._tp = provider
            logger.info("Tracer provider successfully set up (traceloop path).")
        except Exception as e:
            logger.error("Failed to initialize Traceloop SDK: %s", e)
            return


    @classmethod
    def flush(cls, timeout_ms: Optional[int] = None) -> None:
        try:
            if cls._tp is None:
                logger.warning("No tracer provider available for flush.")
                return
            timeout_val = int(timeout_ms) if isinstance(timeout_ms, int) else 10_000
            if hasattr(cls._tp, "force_flush"):
                logger.info("Flushing spans with timeout %d ms...", timeout_val)
                cls._tp.force_flush(timeout_val)  # type: ignore[attr-defined]
                logger.info("Flush complete.")
        except Exception as e:
            logger.error("Exception during flush: %s", e)


    @classmethod
    def shutdown(cls, timeout_ms: Optional[int] = None) -> None:
        _ = timeout_ms
        logger.info("Shutting down SDK...")
        try:
            if cls._tp is not None and hasattr(cls._tp, "shutdown"):
                logger.info("Shutting down tracer provider...")
                cls._tp.shutdown()  # type: ignore[attr-defined]
                logger.info("Tracer provider shutdown complete.")
        except Exception as e:
            logger.error("Exception during tracer shutdown: %s", e)

        cls._initialized = False
        cls._health = None
        cls._tp = None
        logger.info("SDK shutdown complete, state cleared.")
