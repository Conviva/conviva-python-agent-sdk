from __future__ import annotations

from dataclasses import dataclass


Signal = str  # 'traces' | 'logs'


@dataclass
class _State:
    failures: int = 0
    disabled: bool = False


class HealthManager:
    def __init__(self, threshold: int = 5) -> None:
        self._threshold = threshold
        self._state = {"traces": _State(), "logs": _State()}

    def record_success(self, signal: Signal) -> None:
        self._state[signal].failures = 0

    def record_failure(self, signal: Signal) -> None:
        st = self._state[signal]
        if st.disabled:
            return
        st.failures += 1
        if st.failures >= self._threshold:
            st.disabled = True

    def is_enabled(self, signal: Signal) -> bool:
        return not self._state[signal].disabled

    def reset(self, signal: Signal | None = None) -> None:
        if signal is None:
            for s in ("traces", "logs"):
                self._state[s] = _State()
        else:
            self._state[signal] = _State()



