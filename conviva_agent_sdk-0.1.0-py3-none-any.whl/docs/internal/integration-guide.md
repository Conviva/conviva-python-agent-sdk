## Integration Guide — ConvivaAgentSDK (Python)

### Installation
- Download artifacts from GitHub Releases (Python wheel/sdist). No PyPI.

### Configuration
- Required: `CONVIVA_CUSTOMER_KEY` (env) or `customer_key` (init). Missing key → no-op.
- Precedence: init → `CONVIVA_*` → `OTEL_*` → defaults (non-endpoint only).
- Endpoints:
  - Prod: computed `https://<key>.<CONVIVA_AGW_DOMAIN>`, paths auto-appended; default `CONVIVA_AGW_DOMAIN=agw.conviva.com`. Any scheme/path provided in `CONVIVA_AGW_DOMAIN` is sanitized to host.
  - Test: `CONVIVA_ALLOW_TEST_ENDPOINTS=true` and host-only `CONVIVA_TRACES_ENDPOINT`/`CONVIVA_LOGS_ENDPOINT` (localhost/127.0.0.1 only). HTTP without port defaults to `4318`.
- Resource attrs: CSV `CONVIVA_RESOURCE_ATTRIBUTES`; fallback `OTEL_RESOURCE_ATTRIBUTES`.
- Enabled: `enabled` or `CONVIVA_SDK_DISABLED=true` for global no-op.

### Usage — Python
```python
from conviva_agent_sdk import ConvivaAgentSDK
import os

ConvivaAgentSDK.init(
    customer_key=os.environ.get("CONVIVA_CUSTOMER_KEY"),
    service_name="checkout",
    service_version="1.2.3",
    headers={"x-custom": "1"},
    auto_instrumentation=True,
    auto_include=["requests"],
    auto_exclude=["sqlite3"],
    enabled=True,
)

ConvivaAgentSDK.flush(5000)
ConvivaAgentSDK.shutdown(5000)
```

### Behavior Notes
- Gzip always on; system CAs only; no proxies; redirects rejected.
- Reserved headers not overridden; `authorization` is dropped.
- Exporters disable after 5 consecutive failures; re-enable by process restart or `shutdown()` then `init()`.



